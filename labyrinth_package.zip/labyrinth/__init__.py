"""LABYRINTH package"""
