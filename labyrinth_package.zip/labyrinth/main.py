"""
LABYRINTH — Entry point
Run with: python main.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

import logging
logging.basicConfig(
    filename='game.log', level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(funcName)s:%(lineno)d - %(message)s',
    filemode='a'
)

from game import Game

def main():
    """Main entry point"""
    try:
        game = Game()
        game.start_game()
    except KeyboardInterrupt:
        print("\n\nGame interrupted. Goodbye!")
    except Exception as e:
        logging.error(f"Fatal error: {e}", exc_info=True)
        print(f"\n\nFatal error: {e}")
        print("Please report this bug!")

if __name__ == "__main__":
    main()

if __name__ == '__main__':
    main()
